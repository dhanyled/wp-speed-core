<?php
declare(strict_types=1);

namespace WPSpeedCore\Admin;

if (!defined('ABSPATH')) {
    exit;
}

class Dashboard {
    private array $modules;

    public function __construct(array $modules) {
        $this->modules = $modules;
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'actions']);
        add_action('admin_notices', [$this, 'notices']);
    }

    public function menu(): void {
        add_options_page(
            'WP Speed Core',
            'WP Speed Core',
            'manage_options',
            'wp-speed-core',
            [$this, 'render']
        );
    }

    public function actions(): void {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['wpsc_auto_tune']) && check_admin_referer('wpsc_autotune_nonce')) {
            $tuner = $this->modules['tuner'] ?? null;
            if ($tuner) {
                $tuner->apply();
            }
            wp_safe_redirect(add_query_arg(['page' => 'wp-speed-core', 'tuned' => '1'], admin_url('options-general.php')));
            exit;
        }

        if (isset($_POST['wpsc_purge_cache']) && check_admin_referer('wpsc_purge_nonce')) {
            do_action('wpsc_purge_all');
            wp_safe_redirect(add_query_arg(['page' => 'wp-speed-core', 'purged' => '1'], admin_url('options-general.php')));
            exit;
        }

        if (isset($_POST['wpsc_clear_logs']) && check_admin_referer('wpsc_clear_logs_nonce')) {
            $logger = $this->modules['logger'] ?? null;
            if ($logger) {
                $logger->clear();
            }
            wp_safe_redirect(add_query_arg(['page' => 'wp-speed-core', 'log_cleared' => '1'], admin_url('options-general.php')));
            exit;
        }
    }

    public function notices(): void {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'settings_page_wp-speed-core') {
            return;
        }

        if (isset($_GET['tuned'])) {
            echo '<div class="notice notice-success is-dismissible"><p>&#x1F680; <strong>WP Speed Core:</strong> ' . esc_html__('Smart Auto-Tune berhasil diterapkan!', 'wp-speed-core') . '</p></div>';
        }
        if (isset($_GET['purged'])) {
            echo '<div class="notice notice-success is-dismissible"><p>&#x26A1; <strong>WP Speed Core:</strong> ' . esc_html__('Semua cache berhasil dibersihkan.', 'wp-speed-core') . '</p></div>';
        }
        if (isset($_GET['log_cleared'])) {
            echo '<div class="notice notice-info is-dismissible"><p>&#x1F4DD; <strong>WP Speed Core:</strong> ' . esc_html__('Berkas log diagnosa berhasil dibersihkan.', 'wp-speed-core') . '</p></div>';
        }
    }

    public function render(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Akses ditolak.', 'wp-speed-core'));
        }

        $env            = isset($this->modules['env']) ? $this->modules['env']->get() : [];
        $conflicts      = isset($this->modules['arbiter']) ? $this->modules['arbiter']->audit_overlaps() : [];
        $tracking_audit = get_transient('wpsc_tag_audit') ?: [];
        $logger         = $this->modules['logger'] ?? null;

        // Auto snapshot to log if fresh
        if ($logger && isset($this->modules['env'])) {
            static $logged = false;
            if (!$logged) {
                $logger->log_system_snapshot($this->modules['env']);
                $logged = true;
            }
        }

        $log_content = $logger ? $logger->get_logs(100) : 'Logger module inactive.';
        ?>

        <div class="wrap" style="max-width: 1100px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
                <h1 style="font-size: 24px; font-weight: 700; margin: 0;">
                    &#x26A1; WP Speed Core <span style="font-size: 12px; background: #0073aa; color: #fff; padding: 2px 8px; border-radius: 12px; vertical-align: middle;">v1.0.0</span>
                </h1>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <form method="post" style="display: inline;">
                        <?php wp_nonce_field('wpsc_purge_nonce'); ?>
                        <button type="submit" name="wpsc_purge_cache" class="button">&#x1F5D1; <?php esc_html_e('Bersihkan Cache', 'wp-speed-core'); ?></button>
                    </form>
                    <form method="post" style="display: inline;">
                        <?php wp_nonce_field('wpsc_autotune_nonce'); ?>
                        <button type="submit" name="wpsc_auto_tune" class="button button-primary">&#x1F680; <?php esc_html_e('1-Click Auto-Tune', 'wp-speed-core'); ?></button>
                    </form>
                </div>
            </div>

            <?php if (!empty($tracking_audit)): ?>
                <div class="notice notice-warning" style="padding: 15px; margin-bottom: 20px; border-radius: 6px;">
                    <h3 style="margin: 0 0 10px;">&#x26A0;&#xFE0F; <?php esc_html_e('Tag Tracking Duplikat Terdeteksi', 'wp-speed-core'); ?></h3>
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php foreach ($tracking_audit as $dup): ?>
                            <li><strong><?php echo esc_html($dup['type']); ?>:</strong> <?php echo esc_html($dup['msg']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if (!empty($conflicts)): ?>
                <div class="notice notice-info" style="padding: 15px; margin-bottom: 20px; border-radius: 6px;">
                    <h3 style="margin: 0 0 10px;">&#x1F50D; <?php esc_html_e('Smart Arbiter: Fitur Tumpang Tindih', 'wp-speed-core'); ?></h3>
                    <?php foreach ($conflicts as $c): ?>
                        <p style="margin: 5px 0;"><strong><?php echo esc_html($c['plugin']); ?></strong> (<?php echo esc_html(implode(', ', $c['features'])); ?>)<br><em><?php echo esc_html($c['tip']); ?></em></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- System Diagnostic Info -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                <h2 style="margin-top: 0; font-size: 16px; border-bottom: 1px solid #eee; padding-bottom: 10px;">&#x1F4CA; <?php esc_html_e('Environment & Server Stack', 'wp-speed-core'); ?></h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-top: 15px;">
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">WordPress Version</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo esc_html($env['wordpress']['version'] ?? get_bloginfo('version')); ?></div>
                    </div>
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">Web Server</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo esc_html($env['server']['software'] ?? 'Unknown'); ?></div>
                    </div>
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">PHP Version</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo esc_html($env['php']['version'] ?? PHP_VERSION); ?></div>
                    </div>
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">OPcache / JIT</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo !empty($env['php']['opcache']) ? '&#x2705; Active' : '&#x274C; Disabled'; ?></div>
                    </div>
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">Memory Limit</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo esc_html($env['php']['memory_limit'] ?? '128M'); ?></div>
                    </div>
                    <div style="background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #eee;">
                        <div style="color: #666; font-size: 11px; text-transform: uppercase;">Tag Processor API</div>
                        <div style="font-size: 15px; font-weight: 600;"><?php echo !empty($env['wordpress']['has_tag_processor']) ? '&#x2705; Native' : '&#x26A0; Fallback'; ?></div>
                    </div>
                </div>
            </div>

            <!-- Optimization Modules Status -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                <h2 style="margin-top: 0; font-size: 16px; border-bottom: 1px solid #eee; padding-bottom: 10px;">&#x26A1; <?php esc_html_e('Status Modul Optimasi', 'wp-speed-core'); ?></h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 15px; margin-top: 15px;">
                    <div style="border: 1px solid #e2e4e7; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 8px 0;">&#x1F6E1;&#xFE0F; INP Shield (scheduler.yield)</h4>
                        <p style="margin: 0; font-size: 12px; color: #555;">Chunked JS execution menjaga responsivitas browser (INP &lt; 50ms).</p>
                    </div>
                    <div style="border: 1px solid #e2e4e7; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 8px 0;">&#x1F3AF; Auto-LCP Hero Preload</h4>
                        <p style="margin: 0; font-size: 12px; color: #555;">Otomatis sematkan fetchpriority=high pada hero image pertama.</p>
                    </div>
                    <div style="border: 1px solid #e2e4e7; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 8px 0;">&#x26A1; W3C Speculation Rules</h4>
                        <p style="margin: 0; font-size: 12px; color: #555;">Prerender instan halaman selanjutnya di background (0ms TTFB).</p>
                    </div>
                    <div style="border: 1px solid #e2e4e7; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 8px 0;">&#x1F4E6; CSS content-visibility</h4>
                        <p style="margin: 0; font-size: 12px; color: #555;">Memangkas waktu render elemen below-the-fold hingga 40%.</p>
                    </div>
                </div>
            </div>

            <!-- Diagnostics & Audit Logs Section -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px;">
                    <h2 style="margin: 0; font-size: 16px;">&#x1F4DD; <?php esc_html_e('System & Diagnostic Logs', 'wp-speed-core'); ?></h2>
                    <form method="post" onsubmit="return confirm('<?php esc_attr_e('Yakin ingin mengosongkan log?', 'wp-speed-core'); ?>');">
                        <?php wp_nonce_field('wpsc_clear_logs_nonce'); ?>
                        <button type="submit" name="wpsc_clear_logs" class="button button-small">&#x1F5D1; <?php esc_html_e('Kosongkan Log', 'wp-speed-core'); ?></button>
                    </form>
                </div>
                <p style="margin: 0 0 10px; font-size: 12px; color: #666;">
                    <?php esc_html_e('Log diagnosa aktivitas sistem, eksekusi Auto-Tune, pembersihan cache, deteksi duplikasi tag, dan operasi database.', 'wp-speed-core'); ?>
                </p>
                <textarea readonly rows="12" style="width: 100%; font-family: Consolas, Monaco, monospace; font-size: 12px; background: #1e1e1e; color: #d4d4d4; padding: 12px; border-radius: 6px; box-sizing: border-box; line-height: 1.5; white-space: pre-wrap;"><?php echo esc_textarea($log_content); ?></textarea>
            </div>
        </div>

        <?php
    }
}
